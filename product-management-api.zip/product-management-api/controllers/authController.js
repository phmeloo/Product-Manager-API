const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User'); // Modelo de usuário

// Função de registro de usuário
exports.register = async (req, res) => {
  const { username, password } = req.body;

  // Verifica se os dados foram enviados
  if (!username || !password) {
    return res.status(400).json({ message: 'Username and password are required.' });
  }

  try {
    // Verifica se o nome de usuário já existe
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({ message: 'Username already taken.' });
    }

    // Criptografa a senha
    const hashedPassword = await bcrypt.hash(password, 10);
    // Cria o novo usuário
    const newUser = new User({
      username,
      password: hashedPassword,
    });

    // Salva o usuário no banco de dados
    await newUser.save();

    // Retorna uma resposta de sucesso
    res.status(201).json({ message: 'User registered successfully!' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};


exports.login = async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ message: 'Username and password are required.' });
  }

  try {
    // Verifica se o usuário existe
    const user = await User.findOne({ username });
    console.log("User found:", user); // Verifique o usuário encontrado
    if (!user) {
      return res.status(400).json({ message: 'Invalid username or password.' });
    }

    // Verifica se a senha está correta usando bcrypt
    const isMatch = await bcrypt.compare(password, user.password);
    console.log("Password match result:", isMatch); // Verifique o resultado da comparação
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid username or password.' });
    }

    // Gera o token JWT
    const token = jwt.sign(
      { userId: user._id, username: user.username },
      'secrettokenkey', // chave secreta para o JWT
      { expiresIn: '1h' }
    );

    // Retorna o token JWT
    res.status(200).json({ message: 'Login successful!', token });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};
