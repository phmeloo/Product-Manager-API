const Product = require('../models/product');
const createProduct = async (req, res) => {
  try {
    const { name, description, amount, price, categories } = req.body;
    const product = new Product({ name, description, amount, price, categories });
    await product.save();
    res.status(201).json(product);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

const getProducts = async (req, res) => {
  try {
    const products = await Product.find().populate('categories');
    res.json(products);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

module.exports = { createProduct, getProducts };
