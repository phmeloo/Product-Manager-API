const express = require('express');
const { createCategory, getCategories } = require('../controllers/categoryController');
const router = express.Router();

// Rota para criar uma categoria
router.post('/', createCategory);

// Rota para listar todas as categorias
router.get('/', getCategories);

module.exports = router;
